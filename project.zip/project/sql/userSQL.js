'use strict'
var mysql  = require('../conf/db.js');
const mybatisMapper = require('mybatis-mapper');
//mybatisMapper.createMapper([ './db/mapper/AccountMapper.xml' ]);
var format = {language: 'sql', indent: '  '};

module.exports.list =  mysql.simpleQuery( async (con)=>{
    mybatisMapper.createMapper([ './db/mapper/UserMapper.xml' ]);
    var query =  mybatisMapper.getStatement('USER','SELECT_ALL',format);   
    return await con.query(query);
});

module.exports.search =  mysql.simpleQuery( async (con,keyword)=>{
    mybatisMapper.createMapper([ './db/mapper/UserMapper.xml' ]);
    var query =  mybatisMapper.getStatement('USER','SEARCH',keyword, format);  
    console.log(query); 
    return await con.query(query);
});

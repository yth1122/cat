var express = require('express');
var router = express.Router();
var basicSQL = require('../sql/userSQL')

router.get('/user', function(req, res) {
    
    basicSQL.list().then(r=>{
        res.send(r);
    }).catch(function (err){
        res.status(500).send(err.message)
    }) 
});
router.post('/user', function(req, res) {
    var keyword =req.body;
     if(req.body.name){
        keyword.name='%'+keyword.name+'%';
      }else{
          keyword.name='%';
      }

     if(req.body.type){
        keyword.type='%'+keyword.type+'%';
     }else{
         keyword.type='%'
     }

    keyword.date='%'+keyword.date+'%';
    


    basicSQL.search(keyword).then(r=>{
        res.send(r);
    }).catch(function (err){
        res.status(500).send(err.message)
    }) 
});





module.exports = router ;